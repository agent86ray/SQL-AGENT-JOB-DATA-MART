﻿
/*

USE [SQL_AGENT_DATA_MART];
GO


-- clear SQL AGENT DIMENSIONS
TRUNCATE TABLE [dbo].[ETL_DIMENSION_LOG];

TRUNCATE TABLE [dbo].[sysjobs];

TRUNCATE TABLE [dbo].[sysjobsteps];

TRUNCATE TABLE [dbo].[JOB_CURRENT];

*/
