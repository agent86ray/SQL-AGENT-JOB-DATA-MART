﻿CREATE TABLE [dbo].[JOB_EXCLUDE]
(
	[job_id]	[uniqueidentifier]	NOT NULL
,	[name]		[sysname]			NOT NULL
)
